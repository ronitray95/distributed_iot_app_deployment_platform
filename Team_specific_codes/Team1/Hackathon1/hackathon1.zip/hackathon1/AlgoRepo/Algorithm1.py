
def check_moisture(data):
    if data > 45:
        return 1
    return 0