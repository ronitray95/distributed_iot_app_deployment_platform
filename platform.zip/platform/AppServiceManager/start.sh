#!/usr/bin/env bash

gnome-terminal -x ./node_manager.py
gnome-terminal -x ./deployment.py