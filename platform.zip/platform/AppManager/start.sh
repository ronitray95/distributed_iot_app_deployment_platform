#!/usr/bin/env bash

./appManager.py