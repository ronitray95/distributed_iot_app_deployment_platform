import sensor_services as registration
import sensor_manager

#registration.init_services()
sensor_manager.start()
