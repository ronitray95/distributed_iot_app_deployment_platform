#!/usr/bin/env bash

./sensor_manager.py